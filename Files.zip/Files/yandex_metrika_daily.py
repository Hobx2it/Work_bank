#!/usr/bin/env python
# coding: utf-8

# In[1]:


# Импортируем библиотеку requests 
import requests
import json
import pandas as pd
import sys 
from datetime import datetime
from dateutil.relativedelta import relativedelta
from getpass import getpass
from mysql.connector import connect, Error
import re
import os
import time


with connect(
    host="localhost",
    user="root",
    password="Gtxtymr@21",
    database='daily_operations'

) as connection:
    
    max_date = pd.read_sql('SELECT MAX(DATE) FROM yandex_metrika_29640810', connection).iloc[0, 0]

if max_date >= (datetime.today() + relativedelta(days=-2)).date():
    pass
else:
    DayStart = (max_date + relativedelta(days=1)).strftime('%Y-%m-%d')
    DayEnd = (datetime.today() + relativedelta(days=-2)).strftime('%Y-%m-%d')
    
    ACCESS_TOKEN = "AQAAAAAw9dX-AAcT25oGHSQ5jUMmsgzdSSbwPBo"
    metric_id = "29640810"

    url_param = "https://api-metrika.yandex.net/stat/v1/data"
    def get_data_yandex(api_param,header_params):
        # Отправляем get request (запрос GET)
        response = requests.get(
            url_param,
            params=api_param,
            headers=header_params
        )
        # Преобразуем response с помощью json()
        result = response.json()
        #pprint(result) чтобы посмотреть что за оишбка
        result = result['data']
        # Создаем пустой dict (словать данных)
        dict_data = {}
        # Парсим исходный list формата Json в dictionary (словарь данных)
        for i in range(0, len(result)-1):
                dict_data[i] = {
                                'date':result[i]["dimensions"][0]["name"],
                                'traffic-source':result[i]["dimensions"][1]["name"],
                                'traffic-details':result[i]["dimensions"][2]["name"],
                                'users':result[i]["metrics"][0],
                                'new_users':result[i]["metrics"][1],
                                'visits':result[i]["metrics"][2],
                                'upToDayUserRecencyPercentage':result[i]["metrics"][3],
                                'upToWeekUserRecencyPercentage':result[i]["metrics"][4],
                                'upToMonthUserRecencyPercentage':result[i]["metrics"][5],
                                'upToQuarterUserRecencyPercentage':result[i]["metrics"][6],
                                'upToYearUserRecencyPercentage':result[i]["metrics"][7],
                                'overYearUserRecencyPercentage':result[i]["metrics"][8],
                                'oneVisitPerUserPercentage':result[i]["metrics"][9],
                                'upTo3VisitsPerUserPercentage':result[i]["metrics"][10],
                                'upTo7VisitsPerUserPercentage':result[i]["metrics"][11],
                                'upTo31VisitsPerUserPercentage':result[i]["metrics"][12],
                                'over32VisitsPerUserPercentage':result[i]["metrics"][13],
                                'avgDaysBetweenVisits':result[i]["metrics"][14],
                                'pageviews':result[i]["metrics"][15],
                                'bounceRate':result[i]["metrics"][16],
                                'pageDepth':result[i]["metrics"][17],
                                'manPercentage':result[i]["metrics"][18],
                                'mobilePercentage':result[i]["metrics"][19]
                          }
        #Создаем DataFrame из dict (словаря данных или массива данных)
        dict_keys = dict_data[0].keys()
        df = pd.DataFrame.from_dict(dict_data, orient='index',columns=dict_keys)

        return df

        # Задаем параметры для API
    api_param = {
        "ids":metric_id,
        "metrics":"ym:s:users,\
        ym:s:newUsers,\
        ym:s:visits,\
        ym:s:upToDayUserRecencyPercentage,\
        ym:s:upToWeekUserRecencyPercentage,\
        ym:s:upToMonthUserRecencyPercentage,\
        ym:s:upToQuarterUserRecencyPercentage,\
        ym:s:upToYearUserRecencyPercentage,\
        ym:s:overYearUserRecencyPercentage,\
        ym:s:oneVisitPerUserPercentage,\
        ym:s:upTo3VisitsPerUserPercentage,\
        ym:s:upTo7VisitsPerUserPercentage,\
        ym:s:upTo31VisitsPerUserPercentage,\
        ym:s:over32VisitsPerUserPercentage,\
        ym:s:avgDaysBetweenVisits,\
        ym:s:pageviews,\
        ym:s:bounceRate,\
        ym:s:pageDepth,\
        ym:s:manPercentage,\
        ym:s:mobilePercentage",
        "dimensions":"ym:s:date,ym:s:<attribution>TrafficSource,ym:s:<attribution>SourceEngine",
        "date1":DayStart,
        "date2":DayEnd,
        "sort":"ym:s:date",
        "accuracy":"full",
        "limit":100000
        }
    # Задаем параметры header_params
    header_params = {
        'GET': '/management/v1/counters HTTP/1.1',
        'Host': 'api-metrika.yandex.net',
        'Authorization': 'OAuth ' + ACCESS_TOKEN,
        'Content-Type': 'application/x-yametrika+json'
        }

    yandex_data = get_data_yandex(api_param,header_params)
    yandex_data = yandex_data.where(pd.notnull(yandex_data), None)
    
    
    # второй запрос, функцию также переопределим, так как не универсальная
    
    def get_data_yandex(api_param,header_params):
        # Отправляем get request (запрос GET)
        response = requests.get(
            url_param,
            params=api_param,
            headers=header_params
        )
        # Преобразуем response с помощью json()
        result = response.json()
        #pprint(result) чтобы посмотреть что за оишбка
        result = result['data']
        # Создаем пустой dict (словать данных)
        dict_data = {}
        # Парсим исходный list формата Json в dictionary (словарь данных)
        for i in range(0, len(result)-1):
                dict_data[i] = {
                                'date':result[i]["dimensions"][0]["name"],
                                'traffic-source':result[i]["dimensions"][1]["name"],
                                'traffic-details':result[i]["dimensions"][2]["name"],
                                'under18AgePercentage':result[i]["metrics"][0],
                                'upTo24AgePercentage':result[i]["metrics"][1],
                                'upTo34AgePercentage':result[i]["metrics"][2],
                                'upTo44AgePercentage':result[i]["metrics"][3],
                                'over44AgePercentage':result[i]["metrics"][4]
                          }
        #Создаем DataFrame из dict (словаря данных или массива данных)
        dict_keys = dict_data[0].keys()
        df = pd.DataFrame.from_dict(dict_data, orient='index',columns=dict_keys)

        return df

        # Задаем параметры для API вторго запроса
    api_param = {
        "ids":metric_id,
        "metrics":"ym:s:under18AgePercentage,\
        ym:s:upTo24AgePercentage,\
        ym:s:upTo34AgePercentage,\
        ym:s:upTo44AgePercentage,\
        ym:s:over44AgePercentage",
        "dimensions":"ym:s:date,ym:s:<attribution>TrafficSource,ym:s:<attribution>SourceEngine",
        "date1":DayStart,
        "date2":DayEnd,
        "sort":"ym:s:date",
        "accuracy":"full",
        "limit":100000
        }
    
    second_yandex_data = get_data_yandex(api_param,header_params)
    second_yandex_data = second_yandex_data.where(pd.notnull(second_yandex_data), None)
    
    # сделаем merge и в tuple
    yandex_data = yandex_data.merge(second_yandex_data, how='left', on=['date', 'traffic-source', 'traffic-details'])
    
    yandex_data_sql = [tuple(row) for index, row in yandex_data.iterrows()]
    
    
    
    
    

# вставим значения для yandex_metrika_29640810




    with connect(
        host="localhost",
        user="root",
        password='Gtxtymr@21',
        database='daily_operations',
        connection_timeout=28800

    ) as connection:
        query = """INSERT INTO yandex_metrika_29640810
        (date,
        traffic_source,  
        traffic_details,
        users,
        new_users,
        visits,
        upToDayUserRecencyPercentage, 
        upToWeekUserRecencyPercentage,
        upToMonthUserRecencyPercentage,
        upToQuarterUserRecencyPercentage,
        upToYearUserRecencyPercentage,
        overYearUserRecencyPercentage,
        oneVisitPerUserPercentage,
        upTo3VisitsPerUserPercentage,
        upTo7VisitsPerUserPercentage,
        upTo31VisitsPerUserPercentage,
        over32VisitsPerUserPercentage,
        avgDaysBetweenVisits,
        pageviews,
        bounceRate,
        pageDepth,
        manPercentage,
        mobilePercentage,
        under18AgePercentage,
        upTo24AgePercentage,
        upTo34AgePercentage,
        upTo44AgePercentage,
        over44AgePercentage)
        VALUES(%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"""
        with connection.cursor() as cursor:
            for i in range(0, len(yandex_data_sql), 2):
                j = i + 2
                if j > len(yandex_data_sql):
                    j = len(yandex_data_sql)
                try:    
                    cursor.executemany(query, yandex_data_sql[i:j])
                    connection.commit()
                except:
                    continue




